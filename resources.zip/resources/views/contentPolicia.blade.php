@extends('layouts.templateContentPolicia')

    @section('menu_seccion')
        @include('layouts.partials.menu')
    @endsection    	
    
    
   @section('script') 
   	<script>


    </script>
   @endsection