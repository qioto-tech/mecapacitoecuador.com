                    <ul id="nav" class="nav navbar-nav">
                        <li><a href="{{ URL::asset('/') }}">Inicio</a></li>
                        <li><a href="{{ URL::asset('/maestro') }}">Tecnologia</a></li>
                        <li><a href="{{ URL::asset('/estudiante') }}">Idiomas</a></li>
						<li><a href="{{ URL::asset('/abogados') }}">Negocios</a></li>
                        <li><a href="{{ URL::asset('/policia') }}">Otros</a></li>
                        <li><a href="{{ URL::asset('/test') }}">Cursos</a></li>
                        <li><a href="{{ URL::asset('/busqueda') }}">Consultas</a></li>
                    </ul>
