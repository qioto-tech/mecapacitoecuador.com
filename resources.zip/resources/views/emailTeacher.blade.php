<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head>
        <title></title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

        <style type="text/css">
        </style>
        <!--[if !mso]><!--><style type="text/css">
            @import url(https://fonts.googleapis.com/css?family=Cabin:400,700,400italic,700italic);
        </style><link href="https://fonts.googleapis.com/css?family=Cabin:400,700,400italic,700italic" rel="stylesheet" type="text/css" /><!--<![endif]--><style type="text/css">
            .wrapper h1{}.wrapper h1{font-family:Cabin,Avenir,sans-serif}.mso .wrapper h1{font-family:sans-serif !important}.wrapper h2{}.wrapper h2{font-family:Cabin,Avenir,sans-serif}.mso .wrapper h2{font-family:sans-serif !important}.wrapper h3{}.wrapper h3{font-family:Cabin,Avenir,sans-serif}.mso .wrapper h3{font-family:sans-serif !important}.wrapper p,.wrapper ol,.wrapper ul,.wrapper .image{}.wrapper p,.wrapper ol,.wrapper ul,.wrapper .image{font-family:Cabin,Avenir,sans-serif}.mso .wrapper p,.mso .wrapper ol,.mso .wrapper ul,.mso .wrapper .image{font-family:sans-serif !important}.wrapper .btn a{}.wrapper .btn a{font-family:Cabin,Avenir,sans-serif}.mso .wrapper .btn a{font-family:sans-serif !important}.logo div{}.logo div{font-family:Ubuntu,sans-serif}.mso .logo div{font-family:sans-serif 
                                                                                                                                                                                                        !important}.title,.webversion,.fblike,.tweet,.linkedinshare,.forwardtoafriend,.link,.address,.permission,.campaign{}.title,.webversion,.fblike,.tweet,.linkedinshare,.forwardtoafriend,.link,.address,.permission,.campaign{font-family:Cabin,Avenir,sans-serif}.mso .title,.mso .webversion,.mso .fblike,.mso .tweet,.mso .linkedinshare,.mso .forwardtoafriend,.mso .link,.mso .address,.mso .permission,.mso .campaign{font-family:sans-serif !important}body,.wrapper,.emb-editor-canvas{background-color:white}.mso body{background-color:#fff !important}.mso .header,.mso .footer,.mso .one-col-bg,.mso .two-col-bg,.mso .three-col-bg,.mso .one-col-feature-bg{background-color:#1e1e1e}.hr hr{color:#fff;background-color:#fff}.border{background-color:#161616}.wrapper h1{color:#d49344}.wrapper h2{color:#d49344}.wrapper h3{color:#707f8f}.wrapper p,.wrapper ol,.wrapper ul{color:#fff}.wrapper 
            .image{color:#fff}.wrapper a{color:#3dbafd}.wrapper a:hover{color:#0ba8fc !important}.wrapper .btn a{background-color:#4c5b6b;color:#fff}.wrapper .btn a:hover{color:#fff !important}.preheader{background-color:#161616}.title,.webversion,.footer .inner td{color:#e6e6e6}.wrapper .title a,.wrapper .webversion a,.wrapper .footer a{font-weight:bold;color:#e6e6e6}.wrapper .title a:hover,.wrapper .webversion a:hover,.wrapper .footer a:hover{color:#fff !important}.logo div{color:#e6e6e6}.logo div a{color:#e6e6e6}.logo div a:hover{color:#e6e6e6 !important}.column-bg{background-color:#0F82A8}.extra-wide .big-feature{background-color:#0F82A8}.emb-editor-canvas{background-color:#161616}.emb-editor-canvas .wrapper{background-color:#1e1e1e}.fblike,.tweet,.linkedinshare,.forwardtoafriend{background-color:#0f0f0f}
        </style><meta name="robots" content="noindex,nofollow" />
        <meta property="og:title" content="mecpacitoecuador" />
    </head>
    <!--[if mso]>
      <body class="mso">
    <![endif]-->
    <!--[if !mso]><!-->
    <body class="full-padding" style="margin: 0;padding: 0;min-width: 100%;background-color: white;">
        <!--<![endif]-->
        <center class="wrapper" style="display: table;table-layout: fixed;width: 100%;min-width: 620px;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;background-color: white;">
        
            
        

            <table class="one-col-bg" style="border-collapse: collapse;border-spacing: 0;width: 100%;">
                <tbody><tr>
                        <td style="padding: 0;vertical-align: top;" align="center">
                            <table class="one-col centered column-bg" style="border-collapse: collapse;border-spacing: 0;Margin-left: auto;Margin-right: auto;background-color: #0F82A8;width: 800px;table-layout: fixed;" emb-background-style>
                                <tbody><tr>
                                        <td class="column" style="padding: 0;vertical-align: top;text-align: left;">

                                            

                                            <table class="contents" style="border-collapse: collapse;border-spacing: 0;table-layout: fixed;width: 100%;">
                                                <tbody><tr>
                                                        <td class="padded" style="padding: 0;vertical-align: top;padding-left: 32px;padding-right: 32px;word-break: break-word;word-wrap: break-word;text-align: left;">


                                                            <h3 style="font-style: normal;font-weight: 400;Margin-bottom: 0;Margin-top: 32px;font-size: 16px;line-height: 24px;font-family: Cabin,Avenir,sans-serif;color: white;text-align: center;">
                                                                Estimad@ {!!$nombre!!}.
                                                            </h3>
															<h1 style="font-style: normal;font-weight: 400;Margin-bottom: 0;Margin-top: 12px;font-size: 30px;line-height: 40px;font-family: Cabin,Avenir,sans-serif;color: #d49344;text-align: center;">
                                                                Me Capacito Ecuador le saluda</h1>
                                                            
															<p style="font-style: normal;font-weight: 400;Margin-bottom: 0;Margin-top: 16px;font-size: 14px;line-height: 22px;font-family: Cabin,Avenir,sans-serif;color: #fff;">
                                                              	Mi nombre es Ana, administradora de la empresa Capacitate  Ecuador. Me comunico con usted debido a su interes en aprobar el proceso Quiero Ser Maestro 6.
                                                            </p>
															<p style="font-style: normal;font-weight: 400;Margin-bottom: 0;Margin-top: 16px;font-size: 14px;line-height: 22px;font-family: Cabin,Avenir,sans-serif;color: #fff;">
                                                              	Somos un grupo de profesionales independientes al Ministerio de Educacion que ofrecemos simuladores de entrenamiento para medir el nivel de conocimiento que usted posee este momento sobre la especialidad a la cual aplico en el concurso. De esta forma usted tendra una mayor posibilidad de aprobar las pruebas obligatorias exigidas por el Ministerio de Educacion..
                                                            </p>
															<p style="font-style: normal;font-weight: 400;Margin-bottom: 0;Margin-top: 16px;font-size: 14px;line-height: 22px;font-family: Cabin,Avenir,sans-serif;color: #fff;">
																Hemos desarrollado una plataforma virtual similar a la usada por el Ministerio de Educacion en el cual usted podra acceder y encontrar mas de 15 especialidades, con un amplio banco de preguntas donde le permitira resolver los cuestionarios con sus respectiva retroalimetacion y estar preparado para su evaluacion definitiva.
                                                            </p>
															<p style="font-style: normal;font-weight: 400;Margin-bottom: 0;Margin-top: 16px;font-size: 14px;line-height: 22px;font-family: Cabin,Avenir,sans-serif;color: #fff;">
																Le invitamos a formar parte de nuestra comunidad de capacitacion y matenerse informado de los pormenores del proceso QSM6 por este canal
																<br><a href="https://www.facebook.com/quierosermaestro/">facebook</a> <br>
																Cualquier duda o comentario no dude en escribirme.
                                                            </p>
															
															<p style="font-style: normal;font-weight: 400;Margin-bottom: 0;Margin-top: 16px;font-size: 14px;line-height: 22px;font-family: Cabin,Avenir,sans-serif;color: #fff;">
                                                              A continuaci&oacute;n, se encuentran el listado de los similadores que tenemos.  
                                                            </p>
                                                            <ul style="font-style: normal;font-weight: 400;padding-left: 0;Margin-bottom: 32px;Margin-top: 32px;font-size: 14px;line-height: 22px;font-family: Cabin,Avenir,sans-serif;color: #fff;Margin-left: 48px;">
                                                                
                                                                <li style="padding-left: 13px;list-style-type: disc;list-style-position: outside;Margin-bottom: 0;Margin-top: 0;list-style-image: url(https://i9.createsend1.com/static/eb/master/09-onyx/images/bullet.png);text-align: left;">
                                                                <span style="font-style: normal;font-weight: 100;Margin-bottom: 0;Margin-top: 12px;font-size: 20px;line-height: 40px;font-family: Cabin,Avenir,sans-serif;color: white;text-align: center;">
                                                                          PERSONALIDAD </span></li>
                                                                <li style="padding-left: 13px;list-style-type: disc;list-style-position: outside;Margin-bottom: 0;Margin-top: 10px;list-style-image: url(https://i9.createsend1.com/static/eb/master/09-onyx/images/bullet.png);text-align: left;">
                                                                     <span style="font-style: normal;font-weight: 100;Margin-bottom: 0;Margin-top: 12px;font-size: 20px;line-height: 40px;font-family: Cabin,Avenir,sans-serif;color: white;text-align: center;">
                                                                          RAZONAMIENTO </span></li>
                                                                <li style="padding-left: 13px;list-style-type: disc;list-style-position: outside;Margin-bottom: 0;Margin-top: 10px;list-style-image: url(https://i9.createsend1.com/static/eb/master/09-onyx/images/bullet.png);text-align: left;">
                                                                     <span style="font-style: normal;font-weight: 100;Margin-bottom: 0;Margin-top: 12px;font-size: 20px;line-height: 40px;font-family: Cabin,Avenir,sans-serif;color: white;text-align: center;">
                                                                          CIENCIAS NATURALES OCTAVO A DECIMO EGB </span></li>
                                                                <li style="padding-left: 13px;list-style-type: disc;list-style-position: outside;Margin-bottom: 0;Margin-top: 10px;list-style-image: url(https://i9.createsend1.com/static/eb/master/09-onyx/images/bullet.png);text-align: left;">
                                                                     <span style="font-style: normal;font-weight: 100;Margin-bottom: 0;Margin-top: 12px;font-size: 20px;line-height: 40px;font-family: Cabin,Avenir,sans-serif;color: white;text-align: center;">
                                                                          EDUCACION ARTISTICA Y ESTETICA SEGUNDO EGB A BACHILLERATO </span></li>
                                                                <li style="padding-left: 13px;list-style-type: disc;list-style-position: outside;Margin-bottom: 0;Margin-top: 10px;list-style-image: url(https://i9.createsend1.com/static/eb/master/09-onyx/images/bullet.png);text-align: left;">
                                                                     <span style="font-style: normal;font-weight: 100;Margin-bottom: 0;Margin-top: 12px;font-size: 20px;line-height: 40px;font-family: Cabin,Avenir,sans-serif;color: white;text-align: center;">
                                                                          EDUCACION FISICA - SEGUNDO EGB A BACHILLERATO </span></li>
                                                                <li style="padding-left: 13px;list-style-type: disc;list-style-position: outside;Margin-bottom: 0;Margin-top: 10px;list-style-image: url(https://i9.createsend1.com/static/eb/master/09-onyx/images/bullet.png);text-align: left;">
                                                                     <span style="font-style: normal;font-weight: 100;Margin-bottom: 0;Margin-top: 12px;font-size: 20px;line-height: 40px;font-family: Cabin,Avenir,sans-serif;color: white;text-align: center;">
                                                                          EDUCACION INICIAL 2 (DE 3 A 5 A�OS) Y SUB NINVEL PREPARATORIA  (1RO DE EGB) </span></li>
                                                                <li style="padding-left: 13px;list-style-type: disc;list-style-position: outside;Margin-bottom: 0;Margin-top: 10px;list-style-image: url(https://i9.createsend1.com/static/eb/master/09-onyx/images/bullet.png);text-align: left;">
                                                                     <span style="font-style: normal;font-weight: 100;Margin-bottom: 0;Margin-top: 12px;font-size: 20px;line-height: 40px;font-family: Cabin,Avenir,sans-serif;color: white;text-align: center;">
                                                                          EDUCACION PARA LA CIUDADANIA - BACHILLERATO </span></li>
                                                                <li style="padding-left: 13px;list-style-type: disc;list-style-position: outside;Margin-bottom: 0;Margin-top: 10px;list-style-image: url(https://i9.createsend1.com/static/eb/master/09-onyx/images/bullet.png);text-align: left;">
                                                                     <span style="font-style: normal;font-weight: 100;Margin-bottom: 0;Margin-top: 12px;font-size: 20px;line-height: 40px;font-family: Cabin,Avenir,sans-serif;color: white;text-align: center;">
                                                                          SEGUNDO A SEPTIMO E.G.B </span></li>
                                                                <li style="padding-left: 13px;list-style-type: disc;list-style-position: outside;Margin-bottom: 0;Margin-top: 10px;list-style-image: url(https://i9.createsend1.com/static/eb/master/09-onyx/images/bullet.png);text-align: left;">
                                                                     <span style="font-style: normal;font-weight: 100;Margin-bottom: 0;Margin-top: 12px;font-size: 20px;line-height: 40px;font-family: Cabin,Avenir,sans-serif;color: white;text-align: center;">
                                                                          EMPRENDIMIENTO Y GESTION - BACHILLERATO </span></li>
                                                                <li style="padding-left: 13px;list-style-type: disc;list-style-position: outside;Margin-bottom: 0;Margin-top: 10px;list-style-image: url(https://i9.createsend1.com/static/eb/master/09-onyx/images/bullet.png);text-align: left;">
                                                                     <span style="font-style: normal;font-weight: 100;Margin-bottom: 0;Margin-top: 12px;font-size: 20px;line-height: 40px;font-family: Cabin,Avenir,sans-serif;color: white;text-align: center;">
                                                                          ESTUDIOS SOCIALES OCTAVO A DECIMO DE EGB </span></li>
                                                                <li style="padding-left: 13px;list-style-type: disc;list-style-position: outside;Margin-bottom: 0;Margin-top: 10px;list-style-image: url(https://i9.createsend1.com/static/eb/master/09-onyx/images/bullet.png);text-align: left;">
                                                                     <span style="font-style: normal;font-weight: 100;Margin-bottom: 0;Margin-top: 12px;font-size: 20px;line-height: 40px;font-family: Cabin,Avenir,sans-serif;color: white;text-align: center;">
                                                                          FISICA - BACHILLERATO </span></li>
                                                                <li style="padding-left: 13px;list-style-type: disc;list-style-position: outside;Margin-bottom: 0;Margin-top: 10px;list-style-image: url(https://i9.createsend1.com/static/eb/master/09-onyx/images/bullet.png);text-align: left;">
                                                                     <span style="font-style: normal;font-weight: 100;Margin-bottom: 0;Margin-top: 12px;font-size: 20px;line-height: 40px;font-family: Cabin,Avenir,sans-serif;color: white;text-align: center;">
                                                                          HISTORIA Y CIENCIAS SOCIALES BACHILLERATO </span></li>
                                                                <li style="padding-left: 13px;list-style-type: disc;list-style-position: outside;Margin-bottom: 0;Margin-top: 10px;list-style-image: url(https://i9.createsend1.com/static/eb/master/09-onyx/images/bullet.png);text-align: left;">
                                                                     <span style="font-style: normal;font-weight: 100;Margin-bottom: 0;Margin-top: 12px;font-size: 20px;line-height: 40px;font-family: Cabin,Avenir,sans-serif;color: white;text-align: center;">
                                                                          LENGUA Y LITERATURA - OCTAVO EGB A TERCERO BACHILLERATO </span></li>
                                                                <li style="padding-left: 13px;list-style-type: disc;list-style-position: outside;Margin-bottom: 0;Margin-top: 10px;list-style-image: url(https://i9.createsend1.com/static/eb/master/09-onyx/images/bullet.png);text-align: left;">
                                                                     <span style="font-style: normal;font-weight: 100;Margin-bottom: 0;Margin-top: 12px;font-size: 20px;line-height: 40px;font-family: Cabin,Avenir,sans-serif;color: white;text-align: center;">
                                                                          QUIMICA - BACHILLERATO </span></li>
                                                                <li style="padding-left: 13px;list-style-type: disc;list-style-position: outside;Margin-bottom: 0;Margin-top: 10px;list-style-image: url(https://i9.createsend1.com/static/eb/master/09-onyx/images/bullet.png);text-align: left;">
                                                                     <span style="font-style: normal;font-weight: 100;Margin-bottom: 0;Margin-top: 12px;font-size: 20px;line-height: 40px;font-family: Cabin,Avenir,sans-serif;color: white;text-align: center;">
                                                                          MATEMATICA - OCTAVO EGB A TERCERO BACHILLERATO </span></li>
                                                                <li style="padding-left: 13px;list-style-type: disc;list-style-position: outside;Margin-bottom: 0;Margin-top: 10px;list-style-image: url(https://i9.createsend1.com/static/eb/master/09-onyx/images/bullet.png);text-align: left;">
                                                                     <span style="font-style: normal;font-weight: 100;Margin-bottom: 0;Margin-top: 12px;font-size: 20px;line-height: 40px;font-family: Cabin,Avenir,sans-serif;color: white;text-align: center;">
                                                                          PENSAMIENTO FILOSOFICO BACHILLERATO </span></li>
                                                                <li style="padding-left: 13px;list-style-type: disc;list-style-position: outside;Margin-bottom: 0;Margin-top: 10px;list-style-image: url(https://i9.createsend1.com/static/eb/master/09-onyx/images/bullet.png);text-align: left;">
                                                                     <span style="font-style: normal;font-weight: 100;Margin-bottom: 0;Margin-top: 12px;font-size: 20px;line-height: 40px;font-family: Cabin,Avenir,sans-serif;color: white;text-align: center;">
                                                                          BIOLOGIA - BACHILLERATO </span></li>
                                                                
                                                            </ul>
                                                            
                                                            <p style="font-style: normal;font-weight: 400;Margin-bottom: 0;Margin-top: 16px;font-size: 14px;line-height: 22px;font-family: Cabin,Avenir,sans-serif;color: #fff;">
                                                              Te deseamos &Eacute;xitos en la preparaci&oacute;n para tu futura carrera profesional. 
                                                               </p>

                                                        </td>
                                                    </tr>
                                                </tbody></table>

                                            <table class="contents" style="border-collapse: collapse;border-spacing: 0;table-layout: fixed;width: 100%;">
                                                <tbody><tr>
                                                        <td class="padded" style="padding: 0;vertical-align: top;padding-left: 32px;padding-right: 32px;word-break: break-word;word-wrap: break-word;text-align: left;">

                                                            <div style="line-height:10px;font-size:1px">&nbsp;</div>

                                                        </td>
                                                    </tr>
                                                </tbody></table>

                                            <table class="contents" style="border-collapse: collapse;border-spacing: 0;table-layout: fixed;width: 100%;">
                                                <tbody><tr>
                                                        <td class="padded" style="padding: 0;vertical-align: top;padding-left: 32px;padding-right: 32px;word-break: break-word;word-wrap: break-word;text-align: left;">

                                                            <div class="btn btn--center" style="Margin-bottom: 0;Margin-top: 0;text-align: center;">
                                                                <![if !mso]><a style="border-radius: 3px;display: inline-block;font-size: 14px;font-weight: 700;line-height: 24px;padding: 13px 35px 12px 35px;text-align: center;text-decoration: none !important;transition: opacity 0.2s ease-in;color: #fff;font-family: Cabin,Avenir,sans-serif;background-color: #4c5b6b;" href="http://www.yosiquierosermaestro.com">
                                                                    Visitenos en :</a><![endif]>
                                                              <!--[if mso]><v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" href="http://www.iguanatrip.com" style="width:210px" arcsize="7%" fillcolor="#4C5B6B" stroke="f"><v:textbox style="mso-fit-shape-to-text:t" inset="0px,12px,0px,11px"><center style="font-size:14px;line-height:24px;color:#FFFFFF;font-family:sans-serif;font-weight:700;mso-line-height-rule:exactly;mso-text-raise:4px">Registro de operadores</center></v:textbox></v:roundrect><![endif]--></div>

                                                        </td>
                                                    </tr>
                                                </tbody></table>

                                            <div class="column-bottom" style="font-size: 32px;line-height: 32px;transition-timing-function: cubic-bezier(0, 0, 0.2, 1);transition-duration: 150ms;transition-property: all;">&nbsp;</div>
                                        </td>
                                    </tr>
                                </tbody></table>
                        </td>
                    </tr>
                </tbody></table>

            <div class="separator" style="font-size: 20px;line-height: 20px;">&nbsp;</div>

        </center>

    </body></html>
